package com.example.accountmanagement.constant;

public enum Role {
    ADMIN, USER,
}
